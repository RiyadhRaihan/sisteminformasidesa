

<?php $__env->startSection('content'); ?>

<section data-bs-version="5.1" class="form5 cid-t89cJ129HG" id="form5-u">
    <div class="container">
        <div class="mbr-section-head">
            <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2"><strong>Input Data Kependudukan</strong></h3>
        </div>
        <div class="row justify-content-center mt-4">
            <div class="col-lg-8 mx-auto mbr-form" data-form-type="formoid">
                <form action="/warga/store" method="POST">
                    <?php echo csrf_field(); ?>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-2 pt-0">Nama Lengkap</legend>
                            <div class="col-sm-10">
                                <input type="text" name="nama" class="form-control" placeholder="Nama"><br>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-2 pt-0">Nomor Induk Kependudukan</legend>
                            <div class="col-sm-10">
                                <input type="text" name="nik" class="form-control" placeholder="NIK">
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-2 pt-0">Nomor Kartu Keluarga</legend>
                            <div class="col-sm-10">
                                <input type="text" name="nokk" class="form-control" placeholder="No KK"><br>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-2 pt-0">Alamat</legend>
                            <div class="col-sm-10">
                                <input type="text" name="alamat" class="form-control" placeholder="Alamat"><br>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-2 pt-0">Link Alamat Gmaps</legend>
                            <div class="col-sm-10">
                                <input type="text" name="url" class="form-control" placeholder="Url Alamat"><br>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-2 pt-0">Agama</legend>
                            <div class="col-sm-10">
                                <input type="text" name="agama" class="form-control" placeholder="Agama"><br>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-2 pt-0">Jenis Kelamin</legend>
                            <div class="col-sm-10">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="jk" id="gridRadios1" value="L">
                                    <label class="form-check-label" for="gridRadios1">
                                        Laki Laki
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="jk" id="gridRadios1" value="P">
                                    <label class="form-check-label" for="gridRadios1">
                                        Perempuan
                                    </label>
                                </div>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-2 pt-0">Status KTP</legend>
                            <div class="col-sm-10">
                                <input type="text" name="status_ktp" class="form-control" placeholder="Status KTP"><br>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-2 pt-0">Pekerjaan</legend>
                            <div class="col-sm-10">
                                <input type="text" name="pekerjaan" class="form-control" placeholder="Pekerjaan"><br>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-2 pt-0">Nomor BPJS</legend>
                            <div class="col-sm-10">
                                <input type="text" name="nobpjs" class="form-control" placeholder="No BPJS"><br>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-2 pt-0">Nomor NPWP</legend>
                            <div class="col-sm-10">
                                <input type="text" name="npwp" class="form-control" placeholder="NPWP"><br>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-2 pt-0">Status Menetap</legend>
                            <div class="col-sm-10">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="status_menetap" id="gridRadios1" value="Warga Tetap">
                                    <label class="form-check-label" for="gridRadios1">
                                        Warga Tetap
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="status_menetap" id="gridRadios1" value="Warga Tidak Tetap">
                                    <label class="form-check-label" for="gridRadios1">
                                        Warga Tidak Tetap
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="status_menetap" id="gridRadios1" value="Kontrak">
                                    <label class="form-check-label" for="gridRadios1">
                                        Kontrak
                                    </label>
                                </div>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-2 pt-0">Status Perkawinan</legend>
                            <div class="col-sm-10">
                                <input type="text" name="status_perkawinan" class="form-control" placeholder="Status Perkawinan"><br>
                    </fieldset>
                    <input type="submit" class="btn btn-info" name="submit" value="save">
                </form>
            </div>
        </div>
        </fieldset>
    </div>
    </form>
</section>
<script src="<?php echo e(asset('style/assets/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/smoothscroll/smooth-scroll.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/ytplayer/index.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/dropdown/js/navbar-dropdown.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/theme/js/script.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/formoid/formoid.min.js')); ?>"></script>
<!--<?php echo e(asset('style/')); ?> -->

</body>

</html>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RAIHAN\Documents\sid\sid\resources\views/fitur/data.blade.php ENDPATH**/ ?>