<h1>edit data</h1>
<form action="/mus/<?php echo e($mus->id); ?>" method="POST">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>

    <input type="text" name="nama" placeholder="Nama" value=><br>
    <input type="text" name="rw" placeholder="nik"><br>
    <input type="text" name="detail" placeholder="nokk"><br>


    <input type="submit" name="submit" value="save">

</form>

</html><?php /**PATH C:\Users\RAIHAN\Documents\sid\sid\resources\views/warga/edit.blade.php ENDPATH**/ ?>