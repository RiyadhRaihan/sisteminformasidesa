<!DOCTYPE html>
<html>

<head>
    <!-- Site made with Mobirise Website Builder v5.4.1, https://mobirise.com -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="generator" content="Mobirise v5.4.1, mobirise.com">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
    <link rel="shortcut icon" href="<?php echo e(asset('style/assets/images/download-letter-k-luxury-logo-design-concept-template-for-free-128x128.png')); ?>" type="image/x-icon">
    <meta name="description" content="">


    <title>Tentang Kami</title>
    <link rel="stylesheet" href="<?php echo e(asset('style/assets/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style/assets/bootstrap/css/bootstrap-grid.min.cs')); ?>s">
    <link rel="stylesheet" href="<?php echo e(asset('style/assets/bootstrap/css/bootstrap-reboot.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style/assets/dropdown/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style/assets/socicon/css/styles.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style/assets/theme/css/style.css')); ?>">
    <link rel="preload" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap">
    </noscript>
    <link rel="preload" as="style" href="<?php echo e(asset('style/assets/mobirise/css/mbr-additional.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style/assets/mobirise/css/mbr-additional.css')); ?>" type="text/css">




</head>

<body>

    <section data-bs-version="5.1" class="menu menu2 cid-sNkChMy3A4" once="menu" id="menu2-7">

        <nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
            <div class="container">
                <div class="navbar-brand">
                    <span class="navbar-logo">
                        <a href="index.php">
                            <img src="<?php echo e(asset('style/assets/images/download-letter-k-luxury-logo-design-concept-template-for-free-128x128.png')); ?>" alt="Mobirise" style="height: 3rem;">
                        </a>
                    </span>

                </div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-bs-toggle="collapse" data-target="#navbarSupportedContent" data-bs-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <div class="hamburger">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true">
                        <li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="page1.php">Tentang Kami</a></li>
                        <li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="page2.php">Galeri</a></li>
                        <li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="page4.php">Hubungi Kami</a></li>
                    </ul>

                    <div class="navbar-buttons mbr-section-btn"><a class="btn btn-primary display-4" href="page4.php">LOGIN</a></div>
                </div>
            </div>
        </nav>
    </section>

    <section data-bs-version="5.1" class="content4 cid-sNkEsywMgD" id="content4-9">


        <div class="container">
            <div class="row justify-content-center">
                <div class="title col-md-12 col-lg-10">
                    <h3 class="mbr-section-title mbr-fonts-style align-center mb-4 display-2"><strong>PUBLIC SPEAKING ALA GENERASI Z</strong></h3>


                </div>
            </div>
        </div>
    </section>

    <section data-bs-version="5.1" class="content5 cid-sNkEujNbdn" id="content5-a">

        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-12 col-lg-10">

                    <h4 class="mbr-section-subtitle mbr-fonts-style mb-4 display-5">Kenapa Generasi Z harus belajar Public Speaking ?</h4>
                    <p class="mbr-text mbr-fonts-style display-7">Definisi Public Speaking
                        <br> Apa itu public speaking? Pada dasarnya, ini adalah presentasi yang diberikan langsung kepada audiensi. Pidato publik dapat mencakup berbagai macam topik yang berbeda. Tujuan dari pidato bisa untuk mendidik, menghibur atau mempengaruhi pendengar. Sering kali, alat bantu visual dalam bentuk slideshow elektronik digunakan untuk melengkapi pidato dan membuatnya lebih menarik bagi pendengar.
                        <br>
                        <br> Presentasi berbicara di depan umum berbeda dari presentasi online karena presentasi online dapat dilihat atau didengarkan sesuai kemauan pemirsa, sementara pidato publik biasanya terbatas untuk waktu tertentu atau tempat. Presentasi online sering terdiri dari slide atau pre-recorded video dari pembicara (termasuk rekaman presentasi langsung berbicara di depan umum).
                        <br>
                        <br>Pentingnya Public Speaking
                        <br> Jika Temen - temen bertanya pada kebanyakan orang, mereka mungkin akan mengatakan mereka tidak suka berbicara di depan umum. Mungkin bahkan mereka mengaku takut, karena takut berbicara di depan umum adalah rasa takut yang sangat umum. Atau mereka mungkin hanya malu atau tertutup. Untuk alasan ini, banyak orang menghindari berbicara di depan umum jika bisa. Jika Temen - temen salah satu dari orang-orang yang menghindari berbicara di depan umum, maka Temen - temen melewatkan kesempatan.
                        <br>
                        <br> Selama bertahun-tahun, public speaking telah memainkan peran utama dalam pendidikan, pemerintah, dan bisnis. Kata-kata memiliki kekuatan untuk menginformasikan, membujuk, mendidik, dan bahkan menghibur. Dan kata yang diucapkan bahkan bisa lebih kuat daripada kata-kata tertulis di tangan pembicara yang tepat.
                        <br>Apakah Kalian seorang pemilik usaha kecil, mahasiswa atau siswa, Kalian akan mendapatkan keuntungan jika kalian meningkatkan keterampilan public speaking, baik secara pribadi dan profesional. Beberapa manfaat untuk berbicara di depan umum meliputi:
                        <br>• Meningkatkan kepercayaan diri
                        <br>• Ketrampilan riset yang lebih baik
                        <br>• Keterampilan deduktif yang lebih kuat
                        <br>• Kemampuan melakukan advokasi untuk kasus-kasus
                        <br>• Dan banyak lagi&nbsp;
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section data-bs-version="5.1" class="footer3 cid-sNkDYr76ua" once="footers" id="footer3-8">





        <div class="container">
            <div class="media-container-row align-center mbr-white">
                <div class="row row-links">
                    <ul class="foot-menu">





                        <li class="foot-menu-item mbr-fonts-style display-7">Tentang Kami</li>
                        <li class="foot-menu-item mbr-fonts-style display-7">Infografis</li>
                        <li class="foot-menu-item mbr-fonts-style display-7">Galeri</li>
                        <li class="foot-menu-item mbr-fonts-style display-7">Hubungi Kami</li>
                    </ul>
                </div>
                <div class="row social-row">
                    <div class="social-list align-right pb-2">






                        <div class="soc-item">
                            <a href="https://instagram.com/uk.aaaz" target="_blank">
                                <span class="mbr-iconfont mbr-iconfont-social socicon-instagram socicon"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://www.linkedin.com/in/riyadhraihan/" target="_blank">
                                <span class="mbr-iconfont mbr-iconfont-social socicon-linkedin socicon"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://wa.me/082114118591" target="_blank">
                                <span class="mbr-iconfont mbr-iconfont-social socicon-whatsapp socicon"></span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="row row-copirayt">
                    <p class="mbr-text mb-0 mbr-fonts-style mbr-white align-center display-7">
                        © Copyright 2025 SIstem Informasi Desa. All Rights Reserved.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section style="background-color: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif; color:#aaa; font-size:12px; padding: 0; align-items: center; display: flex;"><a href="https://mobirise.site/b" style="flex: 1 1; height: 3rem; padding-left: 1rem;"></a>
        <p style="flex: 0 0 auto; margin:0; padding-right:1rem;"><a href="https://mobirise.site/t" style="color:#aaa;"></a> </p>
    </section>
    <script src="<?php echo e(asset('style/assets/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('style/assets/smoothscroll/smooth-scroll.js')); ?>"></script>
    <script src="<?php echo e(asset('style/assets/ytplayer/index.js')); ?>"></script>
    <script src="<?php echo e(asset('style/assets/dropdown/js/navbar-dropdown.js')); ?>"></script>
    <script src="<?php echo e(asset('style/assets/theme/js/script.js')); ?>"></script>
    <!--<?php echo e(asset('style/')); ?> -->

</body>

</html><?php /**PATH C:\Users\RAIHAN\Documents\sid\sid\resources\views/about.blade.php ENDPATH**/ ?>