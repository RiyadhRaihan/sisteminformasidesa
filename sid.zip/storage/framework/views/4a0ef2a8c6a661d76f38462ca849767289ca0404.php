<!doctype html>
<html lang="en">
<!--<?php echo e(asset('Dashboard/')); ?> -->

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('Dashboard/./assets/img/apple-icon.png')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('Dashboard/./assets/img/favicon.png')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        Admin Sistem Informasi Desa
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="<?php echo e(asset('Dashboard/./assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('Dashboard/./assets/css/paper-dashboard.css?v=2.0.1')); ?>" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="<?php echo e(asset('Dashboard/./assets/demo/demo.css')); ?>" rel="stylesheet" />
</head>

<body class="">
    <div class="wrapper ">
        <div class="sidebar" data-color="white" data-active-color="danger">
            <div class="logo">

                <a class="simple-text logo-normal">
                    Sistem Informasi Desa

                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="active ">
                        <a href="">
                            <i class="nc-icon nc-bank"></i>
                            <p>Input Data Warga</p>
                        </a>
                    </li>
                    <li>
                        <a href="surat">
                            <i class="nc-icon nc-bank"></i>
                            <p>Surat Keterangan</p>
                        </a>
                    </li>
                    <li>
                        <a href="mus">
                            <i class="nc-icon nc-bank"></i>
                            <p>Musrenbang</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main-panel" style="height: 100vh;">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="navbar-brand">Admin</a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <form>
                            <div class="input-group no-border">
                                <input type="text" value="" class="form-control" placeholder="Search...">
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                        <i class="nc-icon nc-zoom-split"></i>
                                    </div>
                                    <a class="btn btn-warning" href="home" role="button">Home Admin</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </nav>
            <!-- End Navbar -->
            <div class="content">
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="description">Input Data Warga</h3>
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Nama</th>
                                <th scope="col">NIK</th>
                                <th scope="col">NO KK</th>
                                <th scope="col">ALAMAT</th>
                                <th scope="col">AGAMA</th>
                                <th scope="col">JENIS KELAMIN</th>
                                <th scope="col">STATUS KTP</th>
                                <th scope="col">PEKERJAAN</th>
                                <th scope="col">BPJS</th>
                                <th scope="col">NPWP</th>
                                <th scope="col">STATUS MENETAP</th>
                                <th scope="col">STATUS PERKAWINAN</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $warga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($w->id); ?></td>
                                <td><?php echo e($w->nama); ?></td>
                                <td><?php echo e($w->nik); ?></td>
                                <td><?php echo e($w->nokk); ?></td>
                                <td><?php echo e($w->alamat); ?></td>
                                <td><?php echo e($w->agama); ?></td>
                                <td><?php echo e($w->jk); ?></td>
                                <td><?php echo e($w->status_ktp); ?></td>
                                <td><?php echo e($w->pekerjaan); ?></td>
                                <td><?php echo e($w->nobpjs); ?></td>
                                <td><?php echo e($w->npwp); ?></td>
                                <td><?php echo e($w->status_menetap); ?></td>
                                <td><?php echo e($w->status_perkawinan); ?></td>
                                <td>
                                    <a href="/warga/<?php echo e($w->id); ?>/edit" class="btn btn-success">edit</a>
                                    <form action="/warga/<?php echo e($w->id); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <input type="submit" value="Delete" class="btn btn-danger">
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>

            <footer class=" footer" style="position: absolute; bottom: 0; width: -webkit-fill-available;">
                <div class="container-fluid">
                    <div class="row">

                        <div class="credits ml-auto">
                            <span class="copyright">
                                © 2022, Sistem Informasi Desa</i>
                            </span>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('Dashboard/./assets/js/core/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Dashboard/./assets/js/core/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Dashboard/./assets/js/core/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Dashboard/./assets/js/plugins/perfect-scrollbar.jquery.min.js')); ?>"></script>
    <!--  Google Maps Plugin    -->
    <script src="<?php echo e(asset('Dashboard/https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE')); ?>"></script>
    <!-- Chart JS -->
    <script src="<?php echo e(asset('Dashboard/./assets/js/plugins/chartjs.min.js')); ?>"></script>
    <!--  Notifications Plugin    -->
    <script src="<?php echo e(asset('Dashboard//assets/js/plugins/bootstrap-notify.js')); ?>."></script>
    <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="<?php echo e(asset('Dashboard/./assets/js/paper-dashboard.min.js?v=2.0.1')); ?>" type="text/javascript"></script>
</body>

</html><?php /**PATH C:\Users\RAIHAN\Documents\sid\sid\resources\views/warga/warga.blade.php ENDPATH**/ ?>