<table border="1">
    <tr>
        <th>Name</th>
        <th>NIK</th>
        <th>NOKK</th>
        <th>alamat</th>
        <th>url</th>
    </tr>
    <?php $__currentLoopData = $warga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($w->name); ?></td>
        <td><?php echo e($w->nik); ?></td>
        <td><?php echo e($w->nokk); ?></td>
        <td><?php echo e($w->alamat); ?></td>
        <td><?php echo e($w->url); ?></td>
    </tr><?php /**PATH C:\Users\RAIHAN\Documents\sid\sid\resources\views/warga.blade.php ENDPATH**/ ?>